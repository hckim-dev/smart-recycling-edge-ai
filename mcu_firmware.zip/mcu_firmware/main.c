// [디버깅] 여기에 Uart2_RX_Interrupt_Enable(1) 만 추가
#include "device_driver.h"
#include "timer.h"
#include "ultrasonic.h"
#include "servo.h"
#include "recycle.h"
#include <stdio.h>

extern volatile unsigned long g_sys_tick;

static void Sys_Init(int baud)
{
    SCB->CPACR |= (0x3 << 10 * 2) | (0x3 << 11 * 2);
    Clock_Init();
    Uart2_Init(baud);
    setvbuf(stdout, NULL, _IONBF, 0);
}

void Main(void)
{
    unsigned long last_tick = 0L;

    Sys_Init(115200);
    printf("\n=== Sensor + Servo + UART RX interrupt ===\n");

    Timer_Init();
    Ultra_Init();
    Recycle_Init();

    Uart2_RX_Interrupt_Enable(1);

    for (;;)
    {
        Servo_Update();

        if ((g_sys_tick - last_tick) >= 500)
        {
            last_tick = g_sys_tick;

            float d0 = Ultra_Read_cm(ULTRA_CH0);
            float d1 = Ultra_Read_cm(ULTRA_CH1);
            float d2 = Ultra_Read_cm(ULTRA_CH2);
            float d3 = Ultra_Read_cm(ULTRA_CH3);

            printf("CH0=%.1fcm  CH1=%.1fcm  CH2=%.1fcm  CH3=%.1fcm\n", d0, d1, d2, d3);
        }
    }
}